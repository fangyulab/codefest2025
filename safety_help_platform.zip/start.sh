#!/bin/bash

echo "========================================"
echo "  安全求助平台 - 啟動腳本"
echo "========================================"
echo ""
echo "正在啟動 Flask 後端..."
echo "後端位址: http://127.0.0.1:5000"
echo ""
echo "請在瀏覽器開啟 frontend.html 來使用前端介面"
echo ""
echo "按 Ctrl+C 停止伺服器"
echo "========================================"
echo ""

python app.py
